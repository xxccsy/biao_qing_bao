
      

      
    import Workflow from './_workflow';


    const createye_mian_biao_qing_shua_xin_148433 = (states) => new Workflow({"type":"DataSource","from":"Workflow","id":"ye_mian_biao_qing_shua_xin_148433","settings":{"workflowId":"7474591081782313000","workflowName":"ye_mian_biao_qing_shua_xin_148433","endType":1,"fromLibrary":null}}, states)

    
      

      export default createye_mian_biao_qing_shua_xin_148433;
      