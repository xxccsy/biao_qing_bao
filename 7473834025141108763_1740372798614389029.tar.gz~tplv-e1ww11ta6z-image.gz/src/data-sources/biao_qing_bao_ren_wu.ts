
      

      
    import Workflow from './_workflow';


    const createbiao_qing_bao_ren_wu = (states) => new Workflow({"type":"DataSource","from":"Workflow","id":"biao_qing_bao_ren_wu","settings":{"workflowId":"7474097041196662795","workflowName":"biao_qing_bao_ren_wu","endType":1,"fromLibrary":null}}, states)

    
      

      export default createbiao_qing_bao_ren_wu;
      