
      

      
    import Workflow from './_workflow';


    const createbian_qing_xi = (states) => new Workflow({"type":"DataSource","from":"Workflow","id":"bian_qing_xi","settings":{"workflowId":"7474108442669973539","workflowName":"bian_qing_xi","endType":1,"fromLibrary":null}}, states)

    
      

      export default createbian_qing_xi;
      