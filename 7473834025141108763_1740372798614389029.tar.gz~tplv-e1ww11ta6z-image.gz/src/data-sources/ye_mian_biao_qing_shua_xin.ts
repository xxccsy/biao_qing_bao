
      

      
    import Workflow from './_workflow';


    const createye_mian_biao_qing_shua_xin = (states) => new Workflow({"type":"DataSource","from":"Workflow","id":"ye_mian_biao_qing_shua_xin","settings":{"workflowId":"7474580300255199270","workflowName":"ye_mian_biao_qing_shua_xin","endType":1,"fromLibrary":null}}, states)

    
      

      export default createye_mian_biao_qing_shua_xin;
      