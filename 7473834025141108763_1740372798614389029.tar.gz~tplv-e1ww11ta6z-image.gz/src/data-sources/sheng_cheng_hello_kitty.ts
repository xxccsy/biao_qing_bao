
      

      
    import Workflow from './_workflow';


    const createsheng_cheng_hello_kitty = (states) => new Workflow({"type":"DataSource","from":"Workflow","id":"sheng_cheng_hello_kitty","settings":{"workflowId":"7474201944287723559","workflowName":"sheng_cheng_hello_kitty","endType":1,"fromLibrary":null}}, states)

    
      

      export default createsheng_cheng_hello_kitty;
      