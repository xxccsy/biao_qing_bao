
      

      
    import Workflow from './_workflow';


    const createbiao_qing_bao = (states) => new Workflow({"type":"DataSource","from":"Workflow","id":"biao_qing_bao","settings":{"workflowId":"7473872398279245859","workflowName":"biao_qing_bao","endType":1,"fromLibrary":null}}, states)

    
      

      export default createbiao_qing_bao;
      