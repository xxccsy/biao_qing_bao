
      

      
    import Workflow from './_workflow';


    const createji_lu_biao_qing_ti_shi = (states) => new Workflow({"type":"DataSource","from":"Workflow","id":"ji_lu_biao_qing_ti_shi","settings":{"workflowId":"7474828656607838246","workflowName":"ji_lu_biao_qing_ti_shi","endType":0,"fromLibrary":null}}, states)

    
      

      export default createji_lu_biao_qing_ti_shi;
      