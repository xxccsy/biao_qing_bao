
      

      
        const config = defineAppConfig({
          pages: [
            'pages/home/index','pages/LYqxAw5MyT/index','pages/808ooHXFl3/index','pages/TByFwqYS91/index','pages/PpJiK3PXIu/index','pages/3KvuZBBb4b/index','pages/I264yZtsLi/index','pages/SJujp8naPh/index','pages/njQ0tKBFU3/index','pages/tGKMF2UWV1/index','pages/Lm5AHgn1oR/index','pages/3sUMRMKPOf/index','pages/VVZYJmXWR9/index','pages/fGSxm8wWtR/index','pages/99AJyEsuVW/index','pages/uGzaT5fACm/index','pages/GWn08MZCKG/index','pages/0J7RTLGPyr/index','pages/7UPjOuLop6/index','pages/acCgDxgvjY/index',
            "pages/webview/index",
          ],
          window: {
            backgroundTextStyle: 'light',
            navigationBarBackgroundColor: '#fff',
            navigationBarTitleText: 'WeChat',
            navigationBarTextStyle: 'black',
          },
          tabBar: {"selectedColor":"#5243FF","backgroundColor":"#ffffff","list":[]}
        })
        
      

      export default config;
      