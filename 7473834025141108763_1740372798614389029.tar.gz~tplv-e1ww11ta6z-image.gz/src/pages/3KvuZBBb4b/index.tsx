
      import  {Page,Text,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page5'}}><Page {...({
      title: "Hello Kitty1",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page5"}>
      <ScopeContext.Provider value={{id: 'Text9'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `提示词：The image is of a Hello Kitty figurine sitting on a pink surface with colorful bubbles in the background. The figurine is white with a pink bow on its head and has blue eyes and a yellow nose. It is wearing a pink dress with white polka dots and has long black whiskers. The background is a gradient of pink, blue, and orange. The overall mood of the image is cheerful and playful.`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 400,letterSpacing: 0,textAlign: "center",justifyContent: "center",lineHeight: 30,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      width: "359px",height: "223px",borderRadius: 0,padding: 0,margin: 0,overflow: "visible",flex: "0 0 auto"},onClick: null,onLoad: null})} id={"Text9"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button9'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `做同款（请先复制）`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      propTitle: "点击时",navType: "inner",pageId: "pg_PSEcsbYGi9"})
    },onLoad: null})} id={"Button9"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button6'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: "41px",overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff",flex: "0 0 auto"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_CcKomtKXXC"})
    },onLoad: null})} id={"Button6"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      