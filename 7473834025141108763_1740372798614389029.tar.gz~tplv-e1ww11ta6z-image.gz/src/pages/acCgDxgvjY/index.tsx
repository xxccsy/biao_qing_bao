
      import  {Page,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page20'}}><Page {...({
      title: "页面21",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: true,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page20"}>
      <ScopeContext.Provider value={{id: 'Button41'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `GitHub`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: false,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: null,onLoad: null})} id={"Button41"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button42'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `Gitee`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: false,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: null,onLoad: null})} id={"Button42"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      