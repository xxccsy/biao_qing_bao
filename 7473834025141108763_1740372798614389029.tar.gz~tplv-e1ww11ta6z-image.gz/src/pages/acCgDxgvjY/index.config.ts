
      

      
        const config = definePageConfig({
          // 这里因为空串会把标题清空，所以需要空格
          navigationBarTitleText: '页面21',
        })
        
      

      export default config;
      