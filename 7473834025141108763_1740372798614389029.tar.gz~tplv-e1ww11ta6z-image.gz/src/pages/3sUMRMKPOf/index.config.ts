
      

      
        const config = definePageConfig({
          // 这里因为空串会把标题清空，所以需要空格
          navigationBarTitleText: '页面13',
        })
        
      

      export default config;
      