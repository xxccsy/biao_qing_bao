
      import  {Page,Text,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page12'}}><Page {...({
      title: "页面13",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page12"}>
      <ScopeContext.Provider value={{id: 'Text12'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `提示词：The image is a digital illustration of a young girl with dark hair and brown eyes. She has a angry   expression on her face, with her eyes wide open and her mouth slightly open. She is wearing a blue and orange striped shirt with a small pocket on the front. The background is white with yellow stars scattered around. The overall style of the illustration is cartoon-like and playful.`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 400,letterSpacing: 0,textAlign: "left",justifyContent: "center",lineHeight: 20,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      width: "auto",height: "auto",borderRadius: 0,padding: 0,margin: 0,overflow: "visible"},onClick: null,onLoad: null})} id={"Text12"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button21'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `做同款（请先复制）`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_r7PQPM2WJE"})
    },onLoad: null})} id={"Button21"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button22'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_LC0pgoeb5W"})
    },onLoad: null})} id={"Button22"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      