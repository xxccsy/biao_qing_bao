
      

      
        const config = definePageConfig({
          // 这里因为空串会把标题清空，所以需要空格
          navigationBarTitleText: '普通生成',
        })
        
      

      export default config;
      