
      import  {Page,TextArea,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page2'}}><Page {...({
      title: "普通生成",openTypeSetting: {
      pageId: "pg_dubFc03NVl",shareCardConfig: {
      shareCardImg: 0},searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page2"}>
      <ScopeContext.Provider value={{id: 'TextArea1'}}><TextArea {...({
      enableLabel: false,label: (function(){
          try {
            return (function() {
              "use strict"

              return `请输入提示词`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),required: false,placeholder: "请输入提示词",enableMaxLength: false,maxLength: 10000,defaultValue: "",layout: null,labelWidth: null,verticalAlign: "top",componentStyle: {
      backgroundColor: {
      hex: "#F1F1F9"},border: null},style: {
      width: "100%",height: "164px",borderRadius: 0,padding: 0,margin: 0,minHeight: "96px",overflow: "visible"},disabled: null,loading: null,onChange: null,onBlur: null,onFocus: null})} id={"TextArea1"}></TextArea></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'TextArea5'}}><TextArea {...({
      enableLabel: true,label: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),required: false,placeholder: "请输入表情包上要生成的文字（可不填）",enableMaxLength: false,maxLength: 10000,defaultValue: null,layout: null,labelWidth: null,verticalAlign: "top",componentStyle: {
      backgroundColor: {
      hex: "#F1F1F9"},border: null},style: {
      width: "100%",height: "164px",borderRadius: 0,padding: 0,margin: 0,minHeight: "96px",overflow: "visible"},disabled: null,loading: null,onChange: null,onBlur: null,onFocus: null})} id={"TextArea5"}></TextArea></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button23'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `生成`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.workflow({
      propTitle: "点击时",successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.biao_qing_bao.id ?? ""} 调用失败，原因：${states.biao_qing_bao.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.biao_qing_bao.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowPayload: {
      USER_INPUT: (function(){
          try {
            return (function() {
              "use strict"

              return states.TextArea1.value;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),input: (function(){
          try {
            return (function() {
              "use strict"

              return states.TextArea5.value;
            })()
          } catch (err) {
            console.error(err)
          }
      })()}})
states.navigation({
      navType: "inner",pageId: "pg_yRfDrFpnt6"})
    },onLoad: () => {
      
    }})} id={"Button23"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button4'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_LC0pgoeb5W"})
    },onLoad: null})} id={"Button4"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button33'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `推荐`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: false,source: 0,icon: "StarFill",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_7QLd72drNB"})
    },onLoad: null})} id={"Button33"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button31'}}><Button {...({
      type: "default",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `生成提示词记录`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Category",iconColor: {
      hex: "#6145ff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#6145ff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#fff",border: "1px solid #6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.workflow({
      successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.ji_lu_biao_qing_ti_shi.id ?? ""} 调用失败，原因：${states.ji_lu_biao_qing_ti_shi.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.ji_lu_biao_qing_ti_shi.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })()})
states.navigation({
      navType: "inner",pageId: "pg_XqwSXMLlQt"})
    },onLoad: null})} id={"Button31"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      