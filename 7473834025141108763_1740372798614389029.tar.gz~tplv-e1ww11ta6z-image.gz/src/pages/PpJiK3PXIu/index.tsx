
      import  {Page,Div,Button,Image,Text} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page6'}}><Page {...({
      title: "Hello Kitty",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page6"}>
      <ScopeContext.Provider value={{id: 'Div1'}}><Div {...({
      style: {
      paddingLeft: 18,paddingTop: 0,paddingRight: 18,paddingBottom: 12,width: "100%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "auto",sizeLimit: {
      },gap: 0,flexFlow: "wrap",borderRadius: 0}})} id={"Div1"}>
      <ScopeContext.Provider value={{id: 'Div2'}}><Div {...({
      style: {
      paddingLeft: 6,paddingTop: 0,paddingRight: 6,paddingBottom: 12,width: "50%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "visible",sizeLimit: {
      },gap: 8,margin: 0,marginLeft: 0,marginTop: 0,marginRight: 0,marginBottom: 0,flexFlow: "column",borderRadius: 0}})} id={"Div2"}>
      <ScopeContext.Provider value={{id: 'Image1'}}><Image {...({
      source: 0,clip: "cover",preview: false,style: {
      borderRadius: 12,border: "1px solid #E2E8F0ff",width: "100%",aspectRatio: "1/1",height: "auto",overflow: "auto",sizeLimit: {
      },enableAspectRatio: true},src: [{
      upload_uri: "picture/2065345721671940_1740207176196322041.png",upload_url: require('@/assets/gB4YNwEl96fYzUN6q-uqZ.png'),name: "6bafcaa8-71c5-4953-99d7-d46d271835c7.png",fileType: "image/png",size: 948779}],onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_XfbyqVA10U"})
    }})} id={"Image1"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div3'}}><Div {...({
      style: {
      width: "100%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "hidden",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "column",borderRadius: 0,enableAspectRatio: false}})} id={"Div3"}>
      <ScopeContext.Provider value={{id: 'Text1'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `Hello kitty1`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 500,letterSpacing: 0,textAlign: "left",justifyContent: "flex-start",lineHeight: 20,color: {
      rgb: {
      r: 51,g: 65,b: 85,a: 1},hsl: {
      h: 215.29411764705878,s: 24.999999999999993,l: 26.666666666666668,a: 1},hsv: {
      h: 215.29411764705878,s: 39.99999999999999,v: 33.33333333333333,a: 1},hex: "#334155"},enableMaxLineCount: true,maxLineCount: 1,style: {
      width: "100%",height: "auto",overflow: "hidden",sizeLimit: {
      },borderRadius: 0,padding: 0}})} id={"Text1"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text2'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `做同款`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 12,fontWeight: 400,letterSpacing: 0,textAlign: "left",justifyContent: "flex-start",lineHeight: 16,color: {
      rgb: {
      r: 100,g: 116,b: 139,a: 1},hsl: {
      h: 215.38461538461536,s: 16.31799163179916,l: 46.86274509803921,a: 1},hsv: {
      h: 215.38461538461536,s: 28.057553956834525,v: 54.509803921568626,a: 1},hex: "#64748B"},enableMaxLineCount: true,maxLineCount: 1,style: {
      width: "100%",height: "auto",overflow: "hidden",sizeLimit: {
      },borderRadius: 0,padding: 0}})} id={"Text2"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div4'}}><Div {...({
      style: {
      paddingLeft: 6,paddingTop: 0,paddingRight: 6,paddingBottom: 12,width: "50%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "visible",sizeLimit: {
      },gap: 8,margin: 0,marginLeft: 0,marginTop: 0,marginRight: 0,marginBottom: 0,flexFlow: "column",borderRadius: 0}})} id={"Div4"}>
      <ScopeContext.Provider value={{id: 'Image2'}}><Image {...({
      source: 0,clip: "cover",preview: false,style: {
      borderRadius: 12,border: "1px solid #E2E8F0ff",width: "100%",aspectRatio: "1/1",height: "auto",overflow: "auto",sizeLimit: {
      },enableAspectRatio: true},src: [{
      upload_uri: "picture/2065345721671940_1740207470949429872.png",upload_url: require('@/assets/Wx3_RX1EI8GjRLXxS6wf-.png'),name: "70d6dd05-ebc1-4fcf-9ee0-55472c74ebaa.png",fileType: "image/png",size: 486280}],onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_7VCrt88Z4Y"})
    }})} id={"Image2"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div5'}}><Div {...({
      style: {
      width: "100%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "hidden",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "column",borderRadius: 0,enableAspectRatio: false}})} id={"Div5"}>
      <ScopeContext.Provider value={{id: 'Text3'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `Hello kitty2`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 500,letterSpacing: 0,textAlign: "left",justifyContent: "flex-start",lineHeight: 20,color: {
      rgb: {
      r: 51,g: 65,b: 85,a: 1},hsl: {
      h: 215.29411764705878,s: 24.999999999999993,l: 26.666666666666668,a: 1},hsv: {
      h: 215.29411764705878,s: 39.99999999999999,v: 33.33333333333333,a: 1},hex: "#334155"},enableMaxLineCount: true,maxLineCount: 1,style: {
      width: "100%",height: "auto",overflow: "hidden",sizeLimit: {
      },borderRadius: 0,padding: 0}})} id={"Text3"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text4'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `做同款`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 12,fontWeight: 400,letterSpacing: 0,textAlign: "left",justifyContent: "flex-start",lineHeight: 16,color: {
      rgb: {
      r: 100,g: 116,b: 139,a: 1},hsl: {
      h: 215.38461538461536,s: 16.31799163179916,l: 46.86274509803921,a: 1},hsv: {
      h: 215.38461538461536,s: 28.057553956834525,v: 54.509803921568626,a: 1},hex: "#64748B"},enableMaxLineCount: true,maxLineCount: 1,style: {
      width: "100%",height: "auto",overflow: "hidden",sizeLimit: {
      },borderRadius: 0,padding: 0}})} id={"Text4"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div6'}}><Div {...({
      style: {
      paddingLeft: 6,paddingTop: 0,paddingRight: 6,paddingBottom: 12,width: "50%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "visible",sizeLimit: {
      },gap: 8,margin: 0,marginLeft: 0,marginTop: 0,marginRight: 0,marginBottom: 0,flexFlow: "column",borderRadius: 0}})} id={"Div6"}>
      <ScopeContext.Provider value={{id: 'Div7'}}><Div {...({
      style: {
      width: "100%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "hidden",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "column",borderRadius: 0,enableAspectRatio: false}})} id={"Div7"}></Div></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div8'}}><Div {...({
      style: {
      paddingLeft: 6,paddingTop: 0,paddingRight: 6,paddingBottom: 12,width: "50%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "visible",sizeLimit: {
      },gap: 8,margin: 0,marginLeft: 0,marginTop: 0,marginRight: 0,marginBottom: 0,flexFlow: "column",borderRadius: 0}})} id={"Div8"}>
      <ScopeContext.Provider value={{id: 'Div9'}}><Div {...({
      style: {
      width: "100%",height: "auto",alignItems: "start",alignContent: "start",justifyContent: "start",overflow: "hidden",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "column",borderRadius: 0,enableAspectRatio: false}})} id={"Div9"}></Div></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button12'}}><Button {...({
      type: "default",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `其它`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: false,source: 0,icon: "Warning",iconColor: {
      hex: "#6145ff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#6145ff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#fff",border: "1px solid #6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      propTitle: "点击时",navType: "inner",pageId: "pg_TRBUzre92m"})
    },onLoad: null})} id={"Button12"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button14'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_LC0pgoeb5W"})
    },onLoad: null})} id={"Button14"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button1'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `自定义生成`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_PSEcsbYGi9"})
    },onLoad: null})} id={"Button1"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      