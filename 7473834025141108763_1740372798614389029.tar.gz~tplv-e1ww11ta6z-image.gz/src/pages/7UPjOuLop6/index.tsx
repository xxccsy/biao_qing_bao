
      import  {Page,Text,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page19'}}><Page {...({
      title: "关于",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page19"}>
      <ScopeContext.Provider value={{id: 'Text13'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `版本：1.2`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 400,letterSpacing: 0,textAlign: "left",justifyContent: "center",lineHeight: 20,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      width: "auto",height: "auto",borderRadius: 0,padding: 0,margin: 0,overflow: "visible"},onClick: null,onLoad: null})} id={"Text13"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button40'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `开源链接`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: false,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_4YJztVl6Lm"})
    },onLoad: null})} id={"Button40"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      