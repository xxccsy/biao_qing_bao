
      import  {Page,Markdown,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page17'}}><Page {...({
      title: "普通生成提示词记录",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page17"}>
      <ScopeContext.Provider value={{id: 'Markdown1'}}><Markdown {...({
      source: 1,fixedContent: "# \n",content: (function(){
          try {
            return (function() {
              "use strict"

              return states.ji_lu_biao_qing_ti_shi.data;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),textAlign: "left",justifyContent: "flex-start",color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      width: "100%",height: "auto",borderRadius: 0,padding: 0,margin: 0,overflow: "visible"},onLoad: null})} id={"Markdown1"}></Markdown></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button30'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_dubFc03NVl"})
    },onLoad: null})} id={"Button30"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button32'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `刷新`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Refresh",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.workflow({
      successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.ji_lu_biao_qing_ti_shi.id ?? ""} 调用失败，原因：${states.ji_lu_biao_qing_ti_shi.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.ji_lu_biao_qing_ti_shi.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })()})
    },onLoad: null})} id={"Button32"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      