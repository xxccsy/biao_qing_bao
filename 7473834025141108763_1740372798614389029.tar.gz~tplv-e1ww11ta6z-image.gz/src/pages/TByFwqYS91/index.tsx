
      import  {Page,TextArea,Button,Text,Image} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page4'}}><Page {...({
      title: "变清晰",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page4"}>
      <ScopeContext.Provider value={{id: 'TextArea4'}}><TextArea {...({
      enableLabel: false,label: (function(){
          try {
            return (function() {
              "use strict"

              return `请输入文本`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),required: false,placeholder: "请输入提示词",enableMaxLength: false,maxLength: 10000,defaultValue: null,layout: null,labelWidth: null,verticalAlign: "top",componentStyle: {
      backgroundColor: {
      hex: "#F1F1F9"},border: null},style: {
      borderRadius: 12,width: "100%",height: "164px",minHeight: "96px",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",gap: null,padding: 0,margin: 0},disabled: null,loading: null,onChange: null,onBlur: null,onFocus: null})} id={"TextArea4"}></TextArea></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button27'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `生成（只需点一次）`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.workflow({
      successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `生成完成`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.bian_qing_xi.id ?? ""} 调用失败，原因：${states.bian_qing_xi.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.bian_qing_xi.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowPayload: {
      USER_INPUT: (function(){
          try {
            return (function() {
              "use strict"

              return states.TextArea4.value;
            })()
          } catch (err) {
            console.error(err)
          }
      })()}})
    },onLoad: null})} id={"Button27"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button7'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_LC0pgoeb5W"})
    },onLoad: null})} id={"Button7"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text25'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `预览图（可下载）`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 100,letterSpacing: 0,textAlign: "left",justifyContent: "center",lineHeight: 20,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      width: "auto",height: "auto",borderRadius: 0,padding: 0,margin: 0,overflow: "visible"},onClick: null,onLoad: null})} id={"Text25"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image5'}}><Image {...({
      source: 1,src: null,bindedSrc: (function(){
          try {
            return (function() {
              "use strict"

              return states.bian_qing_xi.data;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),clip: "cover",preview: true,style: {
      borderRadius: 12,width: "300px",height: "300px",alignItems: null,alignContent: null,justifyContent: null,overflow: "auto",sizeLimit: {
      },gap: null,padding: 0,margin: 0},onClick: null,onLoad: null})} id={"Image5"}></Image></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      