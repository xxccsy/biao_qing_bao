
      import  {Page,Text,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page11'}}><Page {...({
      title: "页面12",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page11"}>
      <ScopeContext.Provider value={{id: 'Text8'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `提示词：The image shows a group of nine small, round, orange-colored toys arranged in a pyramid-like formation. Each toy has a unique expression on its face, ranging from happy to sad. The toys are made of plastic and have a cartoon-like appearance.\\n\\nIn the top left corner, there is a yellow cat wearing a blue hat with a flower on top. Next to it, there are two blue birds with yellow flowers on their heads. In the center of the pyramid, there appears to be a white cat with a green hat and a yellow flower on its head. On the top right corner, it looks like a blue bird with a blue beak and a red beak, and on the bottom left corner there is an orange cat with big eyes and a big smile. In front of the cat, it seems like the cat is standing on its hind legs with its arms stretched out to the sides. The background is white, and there are small pink and yellow stars scattered around the toys.`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 400,letterSpacing: 0,textAlign: "left",justifyContent: "center",lineHeight: 20,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      width: "auto",height: "auto",borderRadius: 0,padding: 0,margin: 0,overflow: "visible"},onClick: null,onLoad: null})} id={"Text8"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button17'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `做同款（请先复制）`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_dubFc03NVl"})
    },onLoad: null})} id={"Button17"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button18'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_LC0pgoeb5W"})
    },onLoad: null})} id={"Button18"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      