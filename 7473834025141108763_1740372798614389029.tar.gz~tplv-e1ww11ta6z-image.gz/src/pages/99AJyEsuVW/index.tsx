
      import  {Page,Image,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page15'}}><Page {...({
      title: "生成大约需15秒",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page15"}>
      <ScopeContext.Provider value={{id: 'Image18'}}><Image {...({
      source: 1,src: null,bindedSrc: (function(){
          try {
            return (function() {
              "use strict"

              return states.biao_qing_bao.data;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),clip: "cover",preview: true,style: {
      borderRadius: 12,width: "320px",height: "320px",alignItems: null,alignContent: null,justifyContent: null,overflow: "auto",sizeLimit: {
      },gap: null,padding: 0,margin: 0},onClick: null,onLoad: null})} id={"Image18"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button24'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_dubFc03NVl"})
    },onLoad: null})} id={"Button24"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      