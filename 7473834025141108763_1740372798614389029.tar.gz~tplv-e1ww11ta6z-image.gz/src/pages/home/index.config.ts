
      

      
        const config = definePageConfig({
          // 这里因为空串会把标题清空，所以需要空格
          navigationBarTitleText: '表情包生成器',
        })
        
      

      export default config;
      