
      import  {Page,Text,Div,Button,Image,Icon} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page1'}}><Page {...({
      enableNav: false,title: "表情包生成器",style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"}})} id={"Page1"}>
      <ScopeContext.Provider value={{id: 'Text5'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `请选择：`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 30,fontWeight: 400,letterSpacing: 0,textAlign: "left",justifyContent: "center",lineHeight: 45,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      width: "364px",height: "30px",borderRadius: 0,padding: 0,margin: 0,overflow: "visible",flex: "0 0 auto"},onClick: null,onLoad: null})} id={"Text5"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div10'}}><Div {...({
      style: {
      paddingLeft: 60,paddingTop: 12,paddingRight: 12,paddingBottom: 12,borderRadius: 5000,backgroundImage: "url(\"https://p3-stone-ui-builder-sign.byteimg.com/tos-cn-i-e1ww11ta6z/picture/1511164480596496_1733819719358298407.png~tplv-e1ww11ta6z-normal.webp?rk3s=daacf5c7&x-expires=1748148778&x-signature=r8WRiR6FR%2FkaCUFWNzFuGq5u5fA%3D\")",backgroundSize: "cover",backgroundPosition: "center center",width: "100%",height: "90px",alignItems: "center",alignContent: "center",justifyContent: "center",overflow: "visible",sizeLimit: {
      },gap: 16,flexFlow: "column"}})} id={"Div10"}>
      <ScopeContext.Provider value={{id: 'Div11'}}><Div {...({
      style: {
      zIndex: 1,top: 25,left: 131,position: "absolute",width: "auto",height: "auto",alignItems: "flex-start",alignContent: "flex-start",justifyContent: "flex-start",overflow: "visible",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "row",borderRadius: 0}})} id={"Div11"}></Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image8'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/2065345721671940_1740234112398803662.png",upload_url: require('@/assets/kZ4jgX12rbiDgT7aTGgjq.png'),name: "4d25a446-f995-446f-8ea3-dccadd6fd9a8.png",fileType: "image/png",size: 236736}],clip: "cover",preview: false,style: {
      borderRadius: 12,zIndex: 1,top: 8,left: 9,right: null,bottom: "auto",position: "absolute",width: "72px",height: "76px",alignItems: null,alignContent: null,justifyContent: null,overflow: "auto",sizeLimit: {
      },gap: null,padding: 0,margin: 0}})} id={"Image8"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon1'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733820619801238114.png",upload_url: require('@/assets/vMp8PrhixSqDoVNV2a6R1.png'),name: "55555.png",fileType: "image/png",size: 1505}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 33,left: 238,zIndex: 1,width: "9px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon1"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon2'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733824183820493498.png",upload_url: require('@/assets/PSdJ-exoqLfWZIWSeBTJg.png'),name: "Star 35.png",fileType: "image/png",size: 1827}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 24,left: 229,zIndex: 1,width: "13px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon2"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image9'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/1511164480596496_1733824607070359260.png",upload_url: require('@/assets/t3fm9yfOH8xwWtqGcfeMW.png'),name: "Frame 1312315792.png",fileType: "image/png",size: 15658}],clip: "cover",preview: false,style: {
      borderRadius: 1000,zIndex: 1,top: 17,left: 275,position: "absolute",width: "56px",height: "56px",overflow: "auto",sizeLimit: {
      },padding: 0,margin: 0},onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_dubFc03NVl"})
    }})} id={"Image9"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text14'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `普通生成`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontWeight: 900,letterSpacing: 0,textAlign: "left",justifyContent: "center",enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "fixed",top: 82,left: 157,zIndex: 1,width: "auto",height: "auto",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0},color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 1},hsl: {
      h: 0,s: 0,l: 100,a: 1},hsv: {
      h: 0,s: 0,v: 100,a: 1},hex: "#FFFFFF"},fontSize: 18,lineHeight: 27})} id={"Text14"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text15'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `会根据用户的提示词进行生成普通表情包`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 10,fontWeight: 400,letterSpacing: 0,textAlign: "center",justifyContent: "center",lineHeight: 12,color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 0.6},hsl: {
      h: 0,s: 0,l: 100,a: 0.6},hsv: {
      h: 0,s: 0,v: 100,a: 0.6},hex: "#FFFFFF"},enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "absolute",top: 53,left: 93,zIndex: 1,width: "169px",height: "24px",overflow: "visible",sizeLimit: {
      },borderRadius: 0,padding: 0,margin: 0}})} id={"Text15"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div12'}}><Div {...({
      style: {
      paddingLeft: 60,paddingTop: 12,paddingRight: 12,paddingBottom: 12,borderRadius: 5000,backgroundImage: "url(\"https://p3-stone-ui-builder-sign.byteimg.com/tos-cn-i-e1ww11ta6z/picture/1511164480596496_1733819719358298407.png~tplv-e1ww11ta6z-normal.webp?rk3s=daacf5c7&x-expires=1748148778&x-signature=r8WRiR6FR%2FkaCUFWNzFuGq5u5fA%3D\")",backgroundSize: "cover",backgroundPosition: "center center",width: "100%",height: "90px",alignItems: "center",alignContent: "center",justifyContent: "center",overflow: "visible",sizeLimit: {
      },gap: 16,flexFlow: "column"}})} id={"Div12"}>
      <ScopeContext.Provider value={{id: 'Div13'}}><Div {...({
      style: {
      zIndex: 1,top: 25,left: 131,position: "absolute",width: "auto",height: "auto",alignItems: "flex-start",alignContent: "flex-start",justifyContent: "flex-start",overflow: "visible",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "row",borderRadius: 0}})} id={"Div13"}>
      <ScopeContext.Provider value={{id: 'Text16'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `人物生成`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontWeight: 900,letterSpacing: 0,textAlign: "left",justifyContent: "center",enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "fixed",top: 184,left: 151,zIndex: 1,width: "auto",height: "auto",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0},color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 1},hsl: {
      h: 0,s: 0,l: 100,a: 1},hsv: {
      h: 0,s: 0,v: 100,a: 1},hex: "#FFFFFF"},fontSize: 18,lineHeight: 27})} id={"Text16"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image10'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/2065345721671940_1740234003840827746.png",upload_url: require('@/assets/ohTMHoyhBt26xB0S2m-5d.png'),name: "9888c97c-a70b-4101-8b52-709345adeafc.png",fileType: "image/png",size: 566007}],clip: "cover",preview: false,style: {
      borderRadius: 12,zIndex: 1,top: 7,left: 10,right: "auto",bottom: "auto",position: "absolute",width: "72px",height: "76px",alignItems: null,alignContent: null,justifyContent: null,overflow: "auto",sizeLimit: {
      },gap: null,padding: 0,margin: 0}})} id={"Image10"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon3'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733820619801238114.png",upload_url: require('@/assets/vMp8PrhixSqDoVNV2a6R1.png'),name: "55555.png",fileType: "image/png",size: 1505}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 33,left: 238,zIndex: 1,width: "9px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon3"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon4'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733824183820493498.png",upload_url: require('@/assets/PSdJ-exoqLfWZIWSeBTJg.png'),name: "Star 35.png",fileType: "image/png",size: 1827}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 24,left: 229,zIndex: 1,width: "13px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon4"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image11'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/1511164480596496_1733824607070359260.png",upload_url: require('@/assets/t3fm9yfOH8xwWtqGcfeMW.png'),name: "Frame 1312315792.png",fileType: "image/png",size: 15658}],clip: "cover",preview: false,style: {
      borderRadius: 1000,zIndex: 1,top: 17,left: 275,position: "absolute",width: "56px",height: "56px",overflow: "auto",sizeLimit: {
      },padding: 0,margin: 0},onClick: (e) => {
      states.navigation({
      propTitle: "点击时",navType: "inner",pageId: "pg_r7PQPM2WJE"})
    }})} id={"Image11"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text17'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `会根据用户的提示词生成人物相关的表情包`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 10,fontWeight: 400,letterSpacing: 0,textAlign: "center",justifyContent: "center",lineHeight: 12,color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 0.6},hsl: {
      h: 0,s: 0,l: 100,a: 0.6},hsv: {
      h: 0,s: 0,v: 100,a: 0.6},hex: "#FFFFFF"},enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "absolute",top: 53,left: 93,zIndex: 1,width: "169px",height: "24px",overflow: "visible",sizeLimit: {
      },borderRadius: 0,padding: 0,margin: 0}})} id={"Text17"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div14'}}><Div {...({
      style: {
      paddingLeft: 60,paddingTop: 12,paddingRight: 12,paddingBottom: 12,borderRadius: 5000,backgroundImage: "url(\"https://p3-stone-ui-builder-sign.byteimg.com/tos-cn-i-e1ww11ta6z/picture/1511164480596496_1733819719358298407.png~tplv-e1ww11ta6z-normal.webp?rk3s=daacf5c7&x-expires=1748148778&x-signature=r8WRiR6FR%2FkaCUFWNzFuGq5u5fA%3D\")",backgroundSize: "cover",backgroundPosition: "center center",width: "100%",height: "90px",alignItems: "center",alignContent: "center",justifyContent: "center",overflow: "visible",sizeLimit: {
      },gap: 16,flexFlow: "column"}})} id={"Div14"}>
      <ScopeContext.Provider value={{id: 'Div15'}}><Div {...({
      style: {
      zIndex: 1,top: 25,left: 131,position: "absolute",width: "auto",height: "auto",alignItems: "flex-start",alignContent: "flex-start",justifyContent: "flex-start",overflow: "visible",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "row",borderRadius: 0}})} id={"Div15"}>
      <ScopeContext.Provider value={{id: 'Text18'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `变清晰`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontWeight: 900,letterSpacing: 0,textAlign: "left",justifyContent: "center",enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "fixed",top: 291,left: 164,zIndex: 1,width: "auto",height: "auto",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0},color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 1},hsl: {
      h: 0,s: 0,l: 100,a: 1},hsv: {
      h: 0,s: 0,v: 100,a: 1},hex: "#FFFFFF"},fontSize: 18,lineHeight: 27})} id={"Text18"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image12'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/2065345721671940_1740233623457983150.png",upload_url: require('@/assets/E5xIQlyNl2iimmqCJo0Bo.png'),name: "ce69a549-00a1-45a2-94b9-c9ca194acd8c.png",fileType: "image/png",size: 506351}],clip: "cover",preview: false,style: {
      borderRadius: 12,zIndex: 1,top: "7px",left: "9px",right: "auto",bottom: "auto",position: "absolute",width: "75px",height: "71px",alignItems: null,alignContent: null,justifyContent: null,overflow: "auto",sizeLimit: {
      },gap: null,padding: 0,margin: 0}})} id={"Image12"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon5'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733820619801238114.png",upload_url: require('@/assets/vMp8PrhixSqDoVNV2a6R1.png'),name: "55555.png",fileType: "image/png",size: 1505}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 33,left: 238,zIndex: 1,width: "9px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon5"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon6'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733824183820493498.png",upload_url: require('@/assets/PSdJ-exoqLfWZIWSeBTJg.png'),name: "Star 35.png",fileType: "image/png",size: 1827}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 24,left: 229,zIndex: 1,width: "13px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon6"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image13'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/1511164480596496_1733824607070359260.png",upload_url: require('@/assets/t3fm9yfOH8xwWtqGcfeMW.png'),name: "Frame 1312315792.png",fileType: "image/png",size: 15658}],clip: "cover",preview: false,style: {
      borderRadius: 1000,zIndex: 1,top: 17,left: 275,position: "absolute",width: "56px",height: "56px",overflow: "auto",sizeLimit: {
      },padding: 0,margin: 0},onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_n4ER09N1c1"})
    }})} id={"Image13"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text19'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `将用户上传的图片变清晰（此功能还在内测，可能不准）`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 10,fontWeight: 400,letterSpacing: 0,textAlign: "center",justifyContent: "center",lineHeight: 12,color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 0.6},hsl: {
      h: 0,s: 0,l: 100,a: 0.6},hsv: {
      h: 0,s: 0,v: 100,a: 0.6},hex: "#FFFFFF"},enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "absolute",top: 53,left: 93,zIndex: 1,width: "169px",height: "24px",overflow: "visible",sizeLimit: {
      },borderRadius: 0,padding: 0,margin: 0}})} id={"Text19"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div16'}}><Div {...({
      style: {
      paddingLeft: 60,paddingTop: 12,paddingRight: 12,paddingBottom: 12,borderRadius: 5000,backgroundImage: "url(\"https://p3-stone-ui-builder-sign.byteimg.com/tos-cn-i-e1ww11ta6z/picture/1511164480596496_1733819719358298407.png~tplv-e1ww11ta6z-normal.webp?rk3s=daacf5c7&x-expires=1748148778&x-signature=r8WRiR6FR%2FkaCUFWNzFuGq5u5fA%3D\")",backgroundSize: "cover",backgroundPosition: "center center",width: "100%",height: "90px",alignItems: "center",alignContent: "center",justifyContent: "center",overflow: "visible",sizeLimit: {
      },gap: 16,flexFlow: "column"}})} id={"Div16"}>
      <ScopeContext.Provider value={{id: 'Div17'}}><Div {...({
      style: {
      zIndex: 1,top: 25,left: 131,position: "absolute",width: "auto",height: "auto",alignItems: "flex-start",alignContent: "flex-start",justifyContent: "flex-start",overflow: "visible",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "row",borderRadius: 0}})} id={"Div17"}>
      <ScopeContext.Provider value={{id: 'Text21'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `Hello Kitty专区`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontWeight: 900,letterSpacing: 0,textAlign: "left",justifyContent: "center",enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "fixed",top: 397,left: 135,zIndex: 1,width: "auto",height: "auto",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0},color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 1},hsl: {
      h: 0,s: 0,l: 100,a: 1},hsv: {
      h: 0,s: 0,v: 100,a: 1},hex: "#FFFFFF"},fontSize: 18,lineHeight: 27})} id={"Text21"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image15'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/2065345721671940_1740233938922139338.png",upload_url: require('@/assets/Jc2ZycH01XNBvvJyIev9I.png'),name: "49e66753-19fb-47c9-87d3-295b2008aff5.png",fileType: "image/png",size: 438524}],clip: "cover",preview: false,style: {
      borderRadius: 12,zIndex: 1,top: 6,left: 10,right: "auto",bottom: "auto",position: "absolute",width: "79px",height: "80px",alignItems: null,alignContent: null,justifyContent: null,overflow: "auto",sizeLimit: {
      },gap: null,padding: 0,margin: 0}})} id={"Image15"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon7'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733820619801238114.png",upload_url: require('@/assets/vMp8PrhixSqDoVNV2a6R1.png'),name: "55555.png",fileType: "image/png",size: 1505}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 33,left: 238,zIndex: 1,width: "9px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon7"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon8'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733824183820493498.png",upload_url: require('@/assets/PSdJ-exoqLfWZIWSeBTJg.png'),name: "Star 35.png",fileType: "image/png",size: 1827}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 24,left: 229,zIndex: 1,width: "13px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon8"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image16'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/1511164480596496_1733824607070359260.png",upload_url: require('@/assets/t3fm9yfOH8xwWtqGcfeMW.png'),name: "Frame 1312315792.png",fileType: "image/png",size: 15658}],clip: "cover",preview: false,style: {
      borderRadius: 1000,zIndex: 1,top: 17,left: 275,position: "absolute",width: "56px",height: "56px",overflow: "auto",sizeLimit: {
      },padding: 0,margin: 0},onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_CcKomtKXXC"})
    }})} id={"Image16"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text22'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `可选择创建属于自己的hellokitty表情包`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 10,fontWeight: 400,letterSpacing: 0,textAlign: "center",justifyContent: "center",lineHeight: 12,color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 0.6},hsl: {
      h: 0,s: 0,l: 100,a: 0.6},hsv: {
      h: 0,s: 0,v: 100,a: 0.6},hex: "#FFFFFF"},enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "absolute",top: 53,left: 93,zIndex: 1,width: "169px",height: "24px",overflow: "visible",sizeLimit: {
      },borderRadius: 0,padding: 0,margin: 0}})} id={"Text22"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Div18'}}><Div {...({
      style: {
      paddingLeft: 60,paddingTop: 12,paddingRight: 12,paddingBottom: 12,borderRadius: 5000,backgroundImage: "url(\"https://p3-stone-ui-builder-sign.byteimg.com/tos-cn-i-e1ww11ta6z/picture/1511164480596496_1733819719358298407.png~tplv-e1ww11ta6z-normal.webp?rk3s=daacf5c7&x-expires=1748148778&x-signature=r8WRiR6FR%2FkaCUFWNzFuGq5u5fA%3D\")",backgroundSize: "cover",backgroundPosition: "center center",width: "100%",height: "90px",alignItems: "center",alignContent: "center",justifyContent: "center",overflow: "visible",sizeLimit: {
      },gap: 16,flexFlow: "column"}})} id={"Div18"}>
      <ScopeContext.Provider value={{id: 'Div19'}}><Div {...({
      style: {
      zIndex: 1,top: 25,left: 131,position: "absolute",width: "auto",height: "auto",alignItems: "flex-start",alignContent: "flex-start",justifyContent: "flex-start",overflow: "visible",sizeLimit: {
      },gap: 4,padding: 0,flexFlow: "row",borderRadius: 0}})} id={"Div19"}>
      <ScopeContext.Provider value={{id: 'Text26'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `AI`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontWeight: 900,letterSpacing: 0,textAlign: "left",justifyContent: "center",enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "fixed",top: 509,left: 165,zIndex: 1,width: "auto",height: "auto",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0},color: {
      hsl: {
      h: 244.51612903225808,s: 1,l: 0.8174,a: 1},hex: "#A9A2FF",rgb: {
      r: 169,g: 162,b: 255,a: 1},hsv: {
      h: 244.51612903225808,s: 0.36519999999999997,v: 1,a: 1},oldHue: 244.51612903225808,source: "hsv"},fontSize: 18,lineHeight: 27})} id={"Text26"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text27'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `推荐`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontWeight: 900,letterSpacing: 0,textAlign: "left",justifyContent: "center",enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "fixed",top: 510,left: 193,zIndex: 1,width: "auto",height: "auto",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0},color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 1},hsl: {
      h: 0,s: 0,l: 100,a: 1},hsv: {
      h: 0,s: 0,v: 100,a: 1},hex: "#FFFFFF"},fontSize: 18,lineHeight: 27})} id={"Text27"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image7'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/2065345721671940_1740310846135974627.png",upload_url: require('@/assets/rV0_4xsmv5-0mLo2-N55t.png'),name: "51751faa-b9c9-4c00-997a-184872ba0830.png",fileType: "image/png",size: 686143}],clip: "cover",preview: false,style: {
      borderRadius: 12,zIndex: 1,top: "6px",left: "12px",right: "auto",bottom: "auto",position: "absolute",width: "75px",height: "78px",alignItems: null,alignContent: null,justifyContent: null,overflow: "auto",sizeLimit: {
      },gap: null,padding: 0,margin: 0}})} id={"Image7"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon9'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733820619801238114.png",upload_url: require('@/assets/vMp8PrhixSqDoVNV2a6R1.png'),name: "55555.png",fileType: "image/png",size: 1505}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 33,left: 238,zIndex: 1,width: "9px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon9"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Icon10'}}><Icon {...({
      source: 1,name: "FaceSmile",src: [{
      upload_uri: "picture/1511164480596496_1733824183820493498.png",upload_url: require('@/assets/PSdJ-exoqLfWZIWSeBTJg.png'),name: "Star 35.png",fileType: "image/png",size: 1827}],color: {
      hex: "#000000"},style: {
      position: "absolute",top: 24,left: 229,zIndex: 1,width: "13px",aspectRatio: "1/1",height: "auto",overflow: "hidden",sizeLimit: {
      },enableAspectRatio: true}})} id={"Icon10"}></Icon></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image14'}}><Image {...({
      source: 0,src: [{
      upload_uri: "picture/1511164480596496_1733824607070359260.png",upload_url: require('@/assets/t3fm9yfOH8xwWtqGcfeMW.png'),name: "Frame 1312315792.png",fileType: "image/png",size: 15658}],clip: "cover",preview: false,style: {
      borderRadius: 1000,zIndex: 1,top: 17,left: 275,position: "absolute",width: "56px",height: "56px",overflow: "auto",sizeLimit: {
      },padding: 0,margin: 0},onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_OKqiBBRIxL"})
    }})} id={"Image14"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text28'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `ai推荐专区`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 10,fontWeight: 400,letterSpacing: 0,textAlign: "center",justifyContent: "center",lineHeight: 12,color: {
      rgb: {
      r: 255,g: 255,b: 255,a: 0.6},hsl: {
      h: 0,s: 0,l: 100,a: 0.6},hsv: {
      h: 0,s: 0,v: 100,a: 0.6},hex: "#FFFFFF"},enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "absolute",top: 53,left: 93,zIndex: 1,width: "169px",height: "24px",overflow: "visible",sizeLimit: {
      },borderRadius: 0,padding: 0,margin: 0}})} id={"Text28"}></Text></ScopeContext.Provider>
      </Div></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button39'}}><Button {...({
      type: "warning",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `关于`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: false,source: 0,icon: "Add",iconColor: {
      hex: "#1a1a1a"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#1a1a1a"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#f3f3f3ff"},disabled: null,loading: null,onClick: null,onLoad: null})} id={"Button39"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Text6'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `made by xx`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 8,fontWeight: 100,letterSpacing: 0,textAlign: "left",justifyContent: "center",lineHeight: 12,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "fixed",top: 720,left: 165,zIndex: 1,width: "auto",height: "auto",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0},onClick: null,onLoad: null})} id={"Text6"}></Text></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      