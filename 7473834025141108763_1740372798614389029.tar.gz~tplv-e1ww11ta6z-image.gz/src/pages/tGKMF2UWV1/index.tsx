
      import  {Page,Text,Button} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page10'}}><Page {...({
      title: "页面11",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: null,onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page10"}>
      <ScopeContext.Provider value={{id: 'Text7'}}><Text {...({
      content: (function(){
          try {
            return (function() {
              "use strict"

              return `提示词：The image is a collection of six cartoon characters in different poses. The characters are arranged in a grid-like pattern on a purple background with small yellow stars scattered around. \\n\\nThe first character on the top left is a yellow smiley face with a big smile and sunglasses on its head. It is wearing a blue outfit with a red hat and a blue scarf around its neck. The second character in the middle is a red helmet with a gold emblem on it. The third character is a white panda with a green leaf on her head. The fourth character is an orange character with a blue hat and blue overalls. The fifth character is another yellow character with an orange hat and yellow scarf. The sixth character is in the center of the image and is holding a small orange ball.\\n\\nAll the characters have happy expressions on their faces and appear to be happy and excited.`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),fontSize: 14,fontWeight: 400,letterSpacing: 0,textAlign: "left",justifyContent: "center",lineHeight: 20,color: {
      hex: "#000000"},enableMaxLineCount: false,maxLineCount: 5,style: {
      position: "relative",top: 0,left: 0,zIndex: 1,width: "380px",height: "331px",alignItems: null,alignContent: null,justifyContent: null,overflow: "visible",sizeLimit: {
      },gap: null,borderRadius: 0,padding: 0,margin: 0,flex: "0 0 auto"},onClick: null,onLoad: null})} id={"Text7"}></Text></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button16'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `做同款（请先复制）`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Add",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      borderRadius: 8,backgroundColor: "#6145FFff",position: "relative",top: 0,left: 0,zIndex: 1,width: "91%",height: "40px",alignItems: null,alignContent: null,justifyContent: null,overflow: "hidden",sizeLimit: {
      },gap: null,padding: 0,margin: 0},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      propTitle: "点击时",navType: "inner",pageId: "pg_dubFc03NVl"})
    },onLoad: null})} id={"Button16"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button15'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      borderRadius: 8,backgroundColor: "#6145FFff",position: "relative",top: 0,left: 0,zIndex: 1,width: "91%",height: "40px",alignItems: null,alignContent: null,justifyContent: null,overflow: "hidden",sizeLimit: {
      },gap: null,padding: 0,margin: 0},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_LC0pgoeb5W"})
    },onLoad: null})} id={"Button15"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      