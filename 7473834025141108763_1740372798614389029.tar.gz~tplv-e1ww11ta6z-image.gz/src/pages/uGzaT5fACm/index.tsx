
      import  {Page,Button,Image} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';

      
import { useLoad, getCurrentInstance, useShareAppMessage, useDidShow } from '@tarojs/taro'
import { observer } from 'mobx-react-lite'
import { usePageEvents, getPageEvent } from "@/utils/use-page-events";

import states from '@/states';

function Index () {
  const query = getCurrentInstance().router?.params;

  useLoad(() => {
    console.log("Page loaded.");
    states.query = query;
  });

  usePageEvents();
  // 分享放在 usePageEvents 中会不生效
  useShareAppMessage(() => {
    getPageEvent()?.onShareAppMessage?.();
    return {};
  });


  return <>
    
      <ScopeContext.Provider value={{id: 'Page16'}}><Page {...({
      title: "AI推荐(稍等时间稍长）",openTypeSetting: {
      pageId: null,shareCardConfig: null,searchParams: null},enableNav: false,style: {
      flexFlow: "column",gap: 16,justifyContent: "start",alignItems: "center",backgroundColor: "#ffffff",borderRadius: 0,padding: 16,width: "100%"},loading: (function(){
          try {
            return (function() {
              "use strict"

              return false;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),onLoad: () => {
      states.workflow({
      successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.ye_mian_biao_qing_shua_xin.id ?? ""} 调用失败，原因：${states.ye_mian_biao_qing_shua_xin.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.ye_mian_biao_qing_shua_xin.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })()})
states.workflow({
      successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.ye_mian_biao_qing_shua_xin_148433.id ?? ""} 调用失败，原因：${states.ye_mian_biao_qing_shua_xin_148433.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.ye_mian_biao_qing_shua_xin_148433.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })()})
    },onUnload: null,onPullDownRefresh: null,onReachBottom: null,onPageScroll: null,onShareAppMessage: null,minHeight: "100%"})} id={"Page16"}>
      <ScopeContext.Provider value={{id: 'Button28'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `刷新`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "Refresh",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "42%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.workflow({
      successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.ye_mian_biao_qing_shua_xin.id ?? ""} 调用失败，原因：${states.ye_mian_biao_qing_shua_xin.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.ye_mian_biao_qing_shua_xin.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })()})
states.workflow({
      successMessage: (function(){
          try {
            return (function() {
              "use strict"

              return void 0;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),errorMessage: (function(){
          try {
            return (function() {
              "use strict"

              return `工作流 ${states.ye_mian_biao_qing_shua_xin_148433.id ?? ""} 调用失败，原因：${states.ye_mian_biao_qing_shua_xin_148433.error ?? ""}`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),workflowId: (function(){
          try {
            return (function() {
              "use strict"

              return states.ye_mian_biao_qing_shua_xin_148433.id;
            })()
          } catch (err) {
            console.error(err)
          }
      })()})
    },onLoad: null})} id={"Button28"}></Button></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image6'}}><Image {...({
      source: 1,src: null,bindedSrc: (function(){
          try {
            return (function() {
              "use strict"

              return states.ye_mian_biao_qing_shua_xin.data;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),clip: "cover",preview: true,style: {
      width: 320,height: "301px",borderRadius: 0,padding: 0,margin: 0,overflow: "auto",flex: "0 0 auto"},onClick: null,onLoad: null})} id={"Image6"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Image19'}}><Image {...({
      source: 1,src: null,bindedSrc: (function(){
          try {
            return (function() {
              "use strict"

              return states.ye_mian_biao_qing_shua_xin_148433.data;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),clip: "cover",preview: true,style: {
      width: 320,height: "291px",borderRadius: 0,padding: 0,margin: 0,overflow: "auto",flex: "0 0 auto"},onClick: null,onLoad: null})} id={"Image19"}></Image></ScopeContext.Provider>
      

      <ScopeContext.Provider value={{id: 'Button29'}}><Button {...({
      type: "primary",enableText: true,content: (function(){
          try {
            return (function() {
              "use strict"

              return `返回`;
            })()
          } catch (err) {
            console.error(err)
          }
      })(),enableIcon: true,source: 0,icon: "ArrowLeft",iconColor: {
      hex: "#ffffff"},iconSrc: null,textStyle: {
      fontSize: 14,fontWeight: 400,lineHeight: 20,color: {
      hex: "#ffffff"}},isOpenType: null,openTypeSetting: {
      mode: "share",pageId: null,shareCardConfig: null,searchParams: null},style: {
      width: "100%",height: 40,overflow: "hidden",borderRadius: 8,padding: 0,margin: 0,backgroundColor: "#6145ffff"},disabled: null,loading: null,onClick: (e) => {
      states.navigation({
      navType: "inner",pageId: "pg_LC0pgoeb5W"})
    },onLoad: null})} id={"Button29"}></Button></ScopeContext.Provider>
      </Page></ScopeContext.Provider>
      
  </>
    };
      
      

      export default observer(Index);
      