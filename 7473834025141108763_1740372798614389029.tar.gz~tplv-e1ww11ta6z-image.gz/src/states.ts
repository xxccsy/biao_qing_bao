
      import  {Text,Div,Image,Icon,Button,Page,TextArea,Markdown,Navigation,showToast} from  '@coze-kit/ui-builder-components-mp';
import  {ScopeContext,elementViewModel} from  '@/elementStates';
import createji_lu_biao_qing_ti_shi  from  '@/data-sources/ji_lu_biao_qing_ti_shi';
import  {COZE_CN_BASE_URL} from  '@coze/api';
import  {CozeAPI,AbortController} from  '@coze/taro-api';
import createye_mian_biao_qing_shua_xin_148433  from  '@/data-sources/ye_mian_biao_qing_shua_xin_148433';
import createye_mian_biao_qing_shua_xin  from  '@/data-sources/ye_mian_biao_qing_shua_xin';
import createbian_qing_xi  from  '@/data-sources/bian_qing_xi';
import createbiao_qing_bao_ren_wu  from  '@/data-sources/biao_qing_bao_ren_wu';
import createsheng_cheng_hello_kitty  from  '@/data-sources/sheng_cheng_hello_kitty';
import createbiao_qing_bao  from  '@/data-sources/biao_qing_bao';
import WorkflowDataSource  from  '@/data-sources/_workflow';
import cozeApi  from  '@/data-sources/_coze-api';
import  {navigateTo,switchTab} from  '@tarojs/taro';
import qs  from  'qs';

      
      import { makeObservable, observable, action, computed } from 'mobx';

      class States {
        initCozeApiClient = (token) => {
      this.cozeApiClient = new CozeAPI({
        baseURL: COZE_CN_BASE_URL,
        token: token,
        headers: {
          'X-TT-ENV': 'prod',
          "X-USE-PPE": 1
        },
        
      })
        return this.cozeApiClient
      };
cozeApiClient = null;
AbortController = AbortController;
app_id = "7473834025141108763";
connector_id_list =  {
  'tt': '10000130',
  'weapp': '10000131',
};
connector_id = this.connector_id_list[process.env.TARO_ENV];
navigation = payload => {
  const routes = [{"path":"/home","title":"首页","isHome":true,"pageId":"pg_LC0pgoeb5W","miniAppTitle":"表情包生成器"},{"path":"/LYqxAw5MyT","title":"页面2","isHome":false,"miniAppTitle":"普通生成","pageId":"pg_dubFc03NVl","searchParams":[],"mpAuth":false},{"path":"/808ooHXFl3","title":"页面3","isHome":false,"miniAppTitle":"人物生成","pageId":"pg_r7PQPM2WJE"},{"path":"/TByFwqYS91","title":"页面4","isHome":false,"miniAppTitle":"变清晰","pageId":"pg_n4ER09N1c1"},{"path":"/PpJiK3PXIu","title":"页面6","isHome":false,"miniAppTitle":"Hello Kitty","pageId":"pg_CcKomtKXXC"},{"path":"/3KvuZBBb4b","title":"页面7","isHome":false,"miniAppTitle":"Hello Kitty1","pageId":"pg_XfbyqVA10U"},{"path":"/I264yZtsLi","title":"页面8","isHome":false,"miniAppTitle":"Hello Kitty2","pageId":"pg_7VCrt88Z4Y"},{"path":"/SJujp8naPh","title":"页面9","isHome":false,"miniAppTitle":"HelloKitty","pageId":"pg_PSEcsbYGi9"},{"path":"/njQ0tKBFU3","title":"页面10","isHome":false,"miniAppTitle":"页面10","pageId":"pg_s3jrAyEPUl"},{"path":"/tGKMF2UWV1","title":"页面11","isHome":false,"miniAppTitle":"页面11","pageId":"pg_kYmuDCMZKK"},{"path":"/Lm5AHgn1oR","title":"页面12","isHome":false,"miniAppTitle":"页面12","pageId":"pg_LMSB6vFX6W"},{"path":"/3sUMRMKPOf","title":"页面13","isHome":false,"miniAppTitle":"页面13","pageId":"pg_6CqdqKDucG"},{"path":"/VVZYJmXWR9","title":"页面14","isHome":false,"miniAppTitle":"其他推荐","pageId":"pg_TRBUzre92m"},{"path":"/fGSxm8wWtR","title":"页面15","isHome":false,"miniAppTitle":"页面15","pageId":"pg_PVwqv6i0Nh"},{"path":"/99AJyEsuVW","title":"页面16","isHome":false,"miniAppTitle":"生成大约需15秒","pageId":"pg_yRfDrFpnt6"},{"path":"/uGzaT5fACm","title":"页面17","isHome":false,"miniAppTitle":"AI推荐(稍等时间稍长）","pageId":"pg_OKqiBBRIxL"},{"path":"/GWn08MZCKG","title":"页面18","isHome":false,"miniAppTitle":"普通生成提示词记录","pageId":"pg_XqwSXMLlQt"},{"path":"/0J7RTLGPyr","title":"页面19","isHome":false,"miniAppTitle":"提示词示例","pageId":"pg_7QLd72drNB"},{"path":"/7UPjOuLop6","title":"页面20","isHome":false,"miniAppTitle":"关于","pageId":"pg_o2ynQkDRhC"},{"path":"/acCgDxgvjY","title":"页面21","isHome":false,"miniAppTitle":"页面21","pageId":"pg_4YJztVl6Lm"}]

  const tabbar = {"selectedColor":"#5243FF","backgroundColor":"#ffffff","list":[]};

  const { navType, navUrl, pageId, searchParams } = payload;
  if (navType === 'outer' && navUrl) {
    navigateTo({
      url: `/pages/webview/index?url=${encodeURIComponent(navUrl)}`,
    });
  } else if (navType === 'inner' && pageId) {
    const route = routes.find(it => it.pageId === pageId);
    if (route) {
      const navigateFunc = tabbar.list.find(it => it.pagePath === `pages${route.path}/index`) ? switchTab : navigateTo;
      navigateFunc({
        url: `/pages${route.path}/index${ searchParams ? '?' + qs.stringify(searchParams) : '' }`
      })
    }
  }
};
;
toast = (payload) => {
  console.log('[showToast]', payload);
    const { toastContent, toastType, toastDuration } = payload;
    showToast?.({
      title: String(toastContent),
      icon: toastType === 'info' ? 'none' : toastType,
      duration: toastDuration,
    });
  };
componentRefMethod = 

(payload) => {
  const { blockId = '', refMethodName = '', refMethodParams = [] } = payload;
  try {
    console.info('[callComponentRefMethod] payload=', payload);

    this[blockId]?.[refMethodName]?.(...refMethodParams);
  } catch (ex) {
    console.error(ex);
  }
};
  ;
workflow = async (payload) => {
  const { workflowId, workflowPayload, errorMessage } = payload;
  const workflow = this?.[workflowId];
  try {
    const ds = await workflow?.trigger(workflowPayload);
    if (ds?.error) {
      this.toast({
        title: errorMessage,
        duration: 3000,
        variant: 'error',
      });
    }
  } catch (ex) {
    console.error(ex);
    console.log('call workflow error message ->', errorMessage);
  }
};;
get Text5() { return elementViewModel.states["Text5"] };
get Div11() { return elementViewModel.states["Div11"] };
get Image8() { return elementViewModel.states["Image8"] };
get Icon1() { return elementViewModel.states["Icon1"] };
get Icon2() { return elementViewModel.states["Icon2"] };
get Image9() { return elementViewModel.states["Image9"] };
get Text14() { return elementViewModel.states["Text14"] };
get Text15() { return elementViewModel.states["Text15"] };
get Div10() { return elementViewModel.states["Div10"] };
get Text16() { return elementViewModel.states["Text16"] };
get Div13() { return elementViewModel.states["Div13"] };
get Image10() { return elementViewModel.states["Image10"] };
get Icon3() { return elementViewModel.states["Icon3"] };
get Icon4() { return elementViewModel.states["Icon4"] };
get Image11() { return elementViewModel.states["Image11"] };
get Text17() { return elementViewModel.states["Text17"] };
get Div12() { return elementViewModel.states["Div12"] };
get Text18() { return elementViewModel.states["Text18"] };
get Div15() { return elementViewModel.states["Div15"] };
get Image12() { return elementViewModel.states["Image12"] };
get Icon5() { return elementViewModel.states["Icon5"] };
get Icon6() { return elementViewModel.states["Icon6"] };
get Image13() { return elementViewModel.states["Image13"] };
get Text19() { return elementViewModel.states["Text19"] };
get Div14() { return elementViewModel.states["Div14"] };
get Text21() { return elementViewModel.states["Text21"] };
get Div17() { return elementViewModel.states["Div17"] };
get Image15() { return elementViewModel.states["Image15"] };
get Icon7() { return elementViewModel.states["Icon7"] };
get Icon8() { return elementViewModel.states["Icon8"] };
get Image16() { return elementViewModel.states["Image16"] };
get Text22() { return elementViewModel.states["Text22"] };
get Div16() { return elementViewModel.states["Div16"] };
get Text26() { return elementViewModel.states["Text26"] };
get Text27() { return elementViewModel.states["Text27"] };
get Div19() { return elementViewModel.states["Div19"] };
get Image7() { return elementViewModel.states["Image7"] };
get Icon9() { return elementViewModel.states["Icon9"] };
get Icon10() { return elementViewModel.states["Icon10"] };
get Image14() { return elementViewModel.states["Image14"] };
get Text28() { return elementViewModel.states["Text28"] };
get Div18() { return elementViewModel.states["Div18"] };
get Button39() { return elementViewModel.states["Button39"] };
get Text6() { return elementViewModel.states["Text6"] };
get Page1() { return elementViewModel.states["Page1"] };
get TextArea1() { return elementViewModel.states["TextArea1"] };
get TextArea5() { return elementViewModel.states["TextArea5"] };
get Button23() { return elementViewModel.states["Button23"] };
get Button4() { return elementViewModel.states["Button4"] };
get Button33() { return elementViewModel.states["Button33"] };
get Button31() { return elementViewModel.states["Button31"] };
get Page2() { return elementViewModel.states["Page2"] };
get TextArea3() { return elementViewModel.states["TextArea3"] };
get Button26() { return elementViewModel.states["Button26"] };
get Button3() { return elementViewModel.states["Button3"] };
get Text24() { return elementViewModel.states["Text24"] };
get Image3() { return elementViewModel.states["Image3"] };
get Page3() { return elementViewModel.states["Page3"] };
get TextArea4() { return elementViewModel.states["TextArea4"] };
get Button27() { return elementViewModel.states["Button27"] };
get Button7() { return elementViewModel.states["Button7"] };
get Text25() { return elementViewModel.states["Text25"] };
get Image5() { return elementViewModel.states["Image5"] };
get Page4() { return elementViewModel.states["Page4"] };
get Image1() { return elementViewModel.states["Image1"] };
get Text1() { return elementViewModel.states["Text1"] };
get Text2() { return elementViewModel.states["Text2"] };
get Div3() { return elementViewModel.states["Div3"] };
get Div2() { return elementViewModel.states["Div2"] };
get Image2() { return elementViewModel.states["Image2"] };
get Text3() { return elementViewModel.states["Text3"] };
get Text4() { return elementViewModel.states["Text4"] };
get Div5() { return elementViewModel.states["Div5"] };
get Div4() { return elementViewModel.states["Div4"] };
get Div7() { return elementViewModel.states["Div7"] };
get Div6() { return elementViewModel.states["Div6"] };
get Div9() { return elementViewModel.states["Div9"] };
get Div8() { return elementViewModel.states["Div8"] };
get Div1() { return elementViewModel.states["Div1"] };
get Button12() { return elementViewModel.states["Button12"] };
get Button14() { return elementViewModel.states["Button14"] };
get Button1() { return elementViewModel.states["Button1"] };
get Page6() { return elementViewModel.states["Page6"] };
get Text9() { return elementViewModel.states["Text9"] };
get Button9() { return elementViewModel.states["Button9"] };
get Button6() { return elementViewModel.states["Button6"] };
get Page5() { return elementViewModel.states["Page5"] };
get Text10() { return elementViewModel.states["Text10"] };
get Button10() { return elementViewModel.states["Button10"] };
get Button11() { return elementViewModel.states["Button11"] };
get Page7() { return elementViewModel.states["Page7"] };
get TextArea2() { return elementViewModel.states["TextArea2"] };
get Button25() { return elementViewModel.states["Button25"] };
get Button13() { return elementViewModel.states["Button13"] };
get Text23() { return elementViewModel.states["Text23"] };
get Image4() { return elementViewModel.states["Image4"] };
get Page8() { return elementViewModel.states["Page8"] };
get Text11() { return elementViewModel.states["Text11"] };
get Button19() { return elementViewModel.states["Button19"] };
get Button20() { return elementViewModel.states["Button20"] };
get Page9() { return elementViewModel.states["Page9"] };
get Text7() { return elementViewModel.states["Text7"] };
get Button16() { return elementViewModel.states["Button16"] };
get Button15() { return elementViewModel.states["Button15"] };
get Page10() { return elementViewModel.states["Page10"] };
get Text8() { return elementViewModel.states["Text8"] };
get Button17() { return elementViewModel.states["Button17"] };
get Button18() { return elementViewModel.states["Button18"] };
get Page11() { return elementViewModel.states["Page11"] };
get Text12() { return elementViewModel.states["Text12"] };
get Button21() { return elementViewModel.states["Button21"] };
get Button22() { return elementViewModel.states["Button22"] };
get Page12() { return elementViewModel.states["Page12"] };
get Image17() { return elementViewModel.states["Image17"] };
get Button8() { return elementViewModel.states["Button8"] };
get Page13() { return elementViewModel.states["Page13"] };
get Text20() { return elementViewModel.states["Text20"] };
get Button2() { return elementViewModel.states["Button2"] };
get Button5() { return elementViewModel.states["Button5"] };
get Page14() { return elementViewModel.states["Page14"] };
get Image18() { return elementViewModel.states["Image18"] };
get Button24() { return elementViewModel.states["Button24"] };
get Page15() { return elementViewModel.states["Page15"] };
get Button28() { return elementViewModel.states["Button28"] };
get Image6() { return elementViewModel.states["Image6"] };
get Image19() { return elementViewModel.states["Image19"] };
get Button29() { return elementViewModel.states["Button29"] };
get Page16() { return elementViewModel.states["Page16"] };
get Markdown1() { return elementViewModel.states["Markdown1"] };
get Button30() { return elementViewModel.states["Button30"] };
get Button32() { return elementViewModel.states["Button32"] };
get Page17() { return elementViewModel.states["Page17"] };
get Button34() { return elementViewModel.states["Button34"] };
get Button35() { return elementViewModel.states["Button35"] };
get Button36() { return elementViewModel.states["Button36"] };
get Button38() { return elementViewModel.states["Button38"] };
get Page18() { return elementViewModel.states["Page18"] };
get Text13() { return elementViewModel.states["Text13"] };
get Button40() { return elementViewModel.states["Button40"] };
get Page19() { return elementViewModel.states["Page19"] };
get Button41() { return elementViewModel.states["Button41"] };
get Button42() { return elementViewModel.states["Button42"] };
get Page20() { return elementViewModel.states["Page20"] };
get Navigation1() { return elementViewModel.states["Navigation1"] };
ji_lu_biao_qing_ti_shi = createji_lu_biao_qing_ti_shi(this);
ye_mian_biao_qing_shua_xin_148433 = createye_mian_biao_qing_shua_xin_148433(this);
ye_mian_biao_qing_shua_xin = createye_mian_biao_qing_shua_xin(this);
bian_qing_xi = createbian_qing_xi(this);
biao_qing_bao_ren_wu = createbiao_qing_bao_ren_wu(this);
sheng_cheng_hello_kitty = createsheng_cheng_hello_kitty(this);
biao_qing_bao = createbiao_qing_bao(this)

        test = 1;

        constructor() {
          makeObservable(this, {
          test: observable,
            initCozeApiClient: action,cozeApiClient: observable,AbortController: observable,app_id: observable,connector_id_list: observable,connector_id: observable,navigation: action,toast: action,componentRefMethod: action,workflow: action,Text5: computed,Div11: computed,Image8: computed,Icon1: computed,Icon2: computed,Image9: computed,Text14: computed,Text15: computed,Div10: computed,Text16: computed,Div13: computed,Image10: computed,Icon3: computed,Icon4: computed,Image11: computed,Text17: computed,Div12: computed,Text18: computed,Div15: computed,Image12: computed,Icon5: computed,Icon6: computed,Image13: computed,Text19: computed,Div14: computed,Text21: computed,Div17: computed,Image15: computed,Icon7: computed,Icon8: computed,Image16: computed,Text22: computed,Div16: computed,Text26: computed,Text27: computed,Div19: computed,Image7: computed,Icon9: computed,Icon10: computed,Image14: computed,Text28: computed,Div18: computed,Button39: computed,Text6: computed,Page1: computed,TextArea1: computed,TextArea5: computed,Button23: computed,Button4: computed,Button33: computed,Button31: computed,Page2: computed,TextArea3: computed,Button26: computed,Button3: computed,Text24: computed,Image3: computed,Page3: computed,TextArea4: computed,Button27: computed,Button7: computed,Text25: computed,Image5: computed,Page4: computed,Image1: computed,Text1: computed,Text2: computed,Div3: computed,Div2: computed,Image2: computed,Text3: computed,Text4: computed,Div5: computed,Div4: computed,Div7: computed,Div6: computed,Div9: computed,Div8: computed,Div1: computed,Button12: computed,Button14: computed,Button1: computed,Page6: computed,Text9: computed,Button9: computed,Button6: computed,Page5: computed,Text10: computed,Button10: computed,Button11: computed,Page7: computed,TextArea2: computed,Button25: computed,Button13: computed,Text23: computed,Image4: computed,Page8: computed,Text11: computed,Button19: computed,Button20: computed,Page9: computed,Text7: computed,Button16: computed,Button15: computed,Page10: computed,Text8: computed,Button17: computed,Button18: computed,Page11: computed,Text12: computed,Button21: computed,Button22: computed,Page12: computed,Image17: computed,Button8: computed,Page13: computed,Text20: computed,Button2: computed,Button5: computed,Page14: computed,Image18: computed,Button24: computed,Page15: computed,Button28: computed,Image6: computed,Image19: computed,Button29: computed,Page16: computed,Markdown1: computed,Button30: computed,Button32: computed,Page17: computed,Button34: computed,Button35: computed,Button36: computed,Button38: computed,Page18: computed,Text13: computed,Button40: computed,Page19: computed,Button41: computed,Button42: computed,Page20: computed,Navigation1: computed,ji_lu_biao_qing_ti_shi: observable,ye_mian_biao_qing_shua_xin_148433: observable,ye_mian_biao_qing_shua_xin: observable,bian_qing_xi: observable,biao_qing_bao_ren_wu: observable,sheng_cheng_hello_kitty: observable,biao_qing_bao: observable
          });
        }
      }

      const states = new States();
      global.states = states;
      console.log('states', states)
      
      

      export default states;
      